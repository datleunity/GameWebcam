﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace HandGestureRecognition
{
    public partial class Form2 : Form
    {
        int point = 0;
        struct Pos
        {
            public int x;
            public int y;
        }

        Pos[] spawn = new Pos[5];
        List<PictureBox> enemies = new List<PictureBox>();
        Timer movementTimer;
        Timer spawnTimer;
        Timer UpdateTimer;

        PictureBox[] Players = new PictureBox[5];
        
        private Form1 form1;

        
        public bool isPlay = false;
        public Form2(Form1 f1)
        {
            InitializeComponent();
            form1 = f1;
            Initalize();
            StartTimers();
        }

        private void Initalize()
        {
            for (int i = 0; i < spawn.Length; i++)
            {
                spawn[i].x = 9 * i * 9;
                spawn[i].y = 97;
            }
            Players[0] = PlayerSlot1;
            Players[1] = PlayerSlot2;
            Players[2] = PlayerSlot3;
            Players[3] = PlayerSlot4;
            Players[4] = PlayerSlot5;
        }

        private void StartTimers()
        {

            movementTimer = new Timer();
            movementTimer.Interval = 10; 
            movementTimer.Tick += Timer_Tick;
            movementTimer.Start();

            spawnTimer = new Timer();
            spawnTimer.Interval = 2000; 
            spawnTimer.Tick += SpawnTimer_Tick;
            spawnTimer.Start();

            UpdateTimer = new Timer();
            UpdateTimer.Interval = 1;
            UpdateTimer.Tick += Update_Tick;
            UpdateTimer.Start();
        }

        int currentCount = 1;
        private void Update_Tick(object sender, EventArgs e)
        {
            if (!isPlay)
            {
                panelTxt.Text = "Game Over";
                return;
            }
            countTxt.Text = form1.count.ToString();

            if (form1.count != 0 && form1.count != currentCount)
            {
                Players[currentCount - 1].Image = null; 
                currentCount = form1.count;
                Image newImage = Image.FromFile(@".\..\..\..\HandGestureRecognition\\Game IMG\\cat1.png");
                Players[currentCount - 1].Image = newImage;

            }
        }

        private void SpawnTimer_Tick(object sender, EventArgs e)
        {
            if (!isPlay) return;

            spawnEnemy();
        }
        int curentIndex = 0;
        private void spawnEnemy()
        {
            if (!isPlay) return;

            Random rand = new Random();
            int index = rand.Next(spawn.Length);
            if (index != curentIndex)
            {
                curentIndex= index;
                PictureBox pictureBox = new PictureBox
                {
                    Size = new Size(70, 70),
                    Location = new Point(spawn[index].x, spawn[index].y),
                    Image = Image.FromFile(@".\..\..\..\HandGestureRecognition\\Game IMG\\Aple.png"),
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    BackColor = (index % 2 == 0) ? Color.Coral : Color.DarkSalmon

                };
                this.Controls.Add(pictureBox);
                pictureBox.BringToFront();
                enemies.Add(pictureBox);
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (!isPlay) return;

            for (int i = enemies.Count - 1; i >= 0; i--)
            {
                PictureBox enemy = enemies[i];
                enemy.Location = new Point(enemy.Location.X, enemy.Location.Y + 1);

                if (enemy.Location.Y > 405)
                {
                    RemoveEnemy(enemy);
                }
            }
        }

        private void RemoveEnemy(PictureBox pictureBox)
        {
            if (!isPlay) return;

            if (pictureBox != null)
            {
                int index = pictureBox.Location.X / 9 / 9;
                this.Controls.Remove(pictureBox);
                pictureBox.Dispose();
                enemies.Remove(pictureBox);
                if (index == form1.count -1)
                {
                    point++;
                    pointTxt.Text = point.ToString();

                } else
                {
                    isPlay = false;
                    bntPlay.Enabled = !isPlay;
                    MessageBox.Show("GameOver");
                }
            }
        }
        void ClearEnemy ()
        {
            for (int i = enemies.Count - 1; i >= 0; i--)
            {
                PictureBox enemy = enemies[i];
                this.Controls.Remove(enemy); 
                enemy.Dispose();              
                enemies.RemoveAt(i);          
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            ClearEnemy();
            point = 0;

            isPlay = true;
            panelTxt.Text = "Playing";
            bntPlay.Enabled = !isPlay;
        }
    }
}
