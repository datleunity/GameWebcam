﻿namespace HandGestureRecognition
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pointTxt = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.countTxt = new System.Windows.Forms.Label();
            this.PlayerSlot1 = new System.Windows.Forms.PictureBox();
            this.PlayerSlot2 = new System.Windows.Forms.PictureBox();
            this.PlayerSlot3 = new System.Windows.Forms.PictureBox();
            this.PlayerSlot4 = new System.Windows.Forms.PictureBox();
            this.PlayerSlot5 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bntPlay = new System.Windows.Forms.Button();
            this.panelTxt = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSlot1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSlot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSlot3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSlot4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSlot5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 543);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 61);
            this.label1.TabIndex = 11;
            this.label1.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(92, 543);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 61);
            this.label2.TabIndex = 12;
            this.label2.Text = "2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(173, 543);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 61);
            this.label3.TabIndex = 13;
            this.label3.Text = "3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(254, 543);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 61);
            this.label4.TabIndex = 14;
            this.label4.Text = "4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(333, 543);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 61);
            this.label5.TabIndex = 15;
            this.label5.Text = "5";
            // 
            // pointTxt
            // 
            this.pointTxt.AutoSize = true;
            this.pointTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pointTxt.Location = new System.Drawing.Point(576, 151);
            this.pointTxt.Name = "pointTxt";
            this.pointTxt.Size = new System.Drawing.Size(36, 39);
            this.pointTxt.TabIndex = 16;
            this.pointTxt.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(447, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 39);
            this.label6.TabIndex = 17;
            this.label6.Text = "POINT:";
            // 
            // countTxt
            // 
            this.countTxt.AutoSize = true;
            this.countTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.countTxt.Location = new System.Drawing.Point(510, 26);
            this.countTxt.Name = "countTxt";
            this.countTxt.Size = new System.Drawing.Size(36, 39);
            this.countTxt.TabIndex = 18;
            this.countTxt.Text = "0";
            // 
            // PlayerSlot1
            // 
            this.PlayerSlot1.BackColor = System.Drawing.Color.Coral;
            this.PlayerSlot1.Image = global::HandGestureRecognition.Properties.Resources.cat1;
            this.PlayerSlot1.InitialImage = null;
            this.PlayerSlot1.Location = new System.Drawing.Point(9, 475);
            this.PlayerSlot1.Name = "PlayerSlot1";
            this.PlayerSlot1.Size = new System.Drawing.Size(73, 65);
            this.PlayerSlot1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerSlot1.TabIndex = 10;
            this.PlayerSlot1.TabStop = false;
            // 
            // PlayerSlot2
            // 
            this.PlayerSlot2.BackColor = System.Drawing.Color.DarkSalmon;
            this.PlayerSlot2.InitialImage = null;
            this.PlayerSlot2.Location = new System.Drawing.Point(88, 475);
            this.PlayerSlot2.Name = "PlayerSlot2";
            this.PlayerSlot2.Size = new System.Drawing.Size(73, 65);
            this.PlayerSlot2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerSlot2.TabIndex = 9;
            this.PlayerSlot2.TabStop = false;
            // 
            // PlayerSlot3
            // 
            this.PlayerSlot3.BackColor = System.Drawing.Color.Coral;
            this.PlayerSlot3.InitialImage = null;
            this.PlayerSlot3.Location = new System.Drawing.Point(167, 475);
            this.PlayerSlot3.Name = "PlayerSlot3";
            this.PlayerSlot3.Size = new System.Drawing.Size(73, 65);
            this.PlayerSlot3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerSlot3.TabIndex = 8;
            this.PlayerSlot3.TabStop = false;
            // 
            // PlayerSlot4
            // 
            this.PlayerSlot4.BackColor = System.Drawing.Color.DarkSalmon;
            this.PlayerSlot4.InitialImage = null;
            this.PlayerSlot4.Location = new System.Drawing.Point(246, 475);
            this.PlayerSlot4.Name = "PlayerSlot4";
            this.PlayerSlot4.Size = new System.Drawing.Size(73, 65);
            this.PlayerSlot4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerSlot4.TabIndex = 7;
            this.PlayerSlot4.TabStop = false;
            // 
            // PlayerSlot5
            // 
            this.PlayerSlot5.BackColor = System.Drawing.Color.Coral;
            this.PlayerSlot5.InitialImage = null;
            this.PlayerSlot5.Location = new System.Drawing.Point(325, 475);
            this.PlayerSlot5.Name = "PlayerSlot5";
            this.PlayerSlot5.Size = new System.Drawing.Size(73, 65);
            this.PlayerSlot5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerSlot5.TabIndex = 6;
            this.PlayerSlot5.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Coral;
            this.pictureBox5.ErrorImage = global::HandGestureRecognition.Properties.Resources.Ro1;
            this.pictureBox5.Location = new System.Drawing.Point(325, 97);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(73, 443);
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.DarkSalmon;
            this.pictureBox3.Location = new System.Drawing.Point(246, 97);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(73, 443);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Coral;
            this.pictureBox4.Location = new System.Drawing.Point(167, 97);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(73, 443);
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.DarkSalmon;
            this.pictureBox2.Location = new System.Drawing.Point(88, 97);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(73, 443);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Coral;
            this.pictureBox1.Location = new System.Drawing.Point(9, 97);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 443);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // bntPlay
            // 
            this.bntPlay.Location = new System.Drawing.Point(447, 261);
            this.bntPlay.Name = "bntPlay";
            this.bntPlay.Size = new System.Drawing.Size(164, 57);
            this.bntPlay.TabIndex = 19;
            this.bntPlay.Text = "Play";
            this.bntPlay.UseVisualStyleBackColor = true;
            this.bntPlay.Click += new System.EventHandler(this.button1_Click);
            // 
            // panelTxt
            // 
            this.panelTxt.AutoSize = true;
            this.panelTxt.Font = new System.Drawing.Font("Microsoft YaHei UI", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelTxt.Location = new System.Drawing.Point(19, 42);
            this.panelTxt.Name = "panelTxt";
            this.panelTxt.Size = new System.Drawing.Size(95, 36);
            this.panelTxt.TabIndex = 20;
            this.panelTxt.Text = "Game";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(638, 603);
            this.Controls.Add(this.panelTxt);
            this.Controls.Add(this.bntPlay);
            this.Controls.Add(this.countTxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pointTxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PlayerSlot1);
            this.Controls.Add(this.PlayerSlot2);
            this.Controls.Add(this.PlayerSlot3);
            this.Controls.Add(this.PlayerSlot4);
            this.Controls.Add(this.PlayerSlot5);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSlot1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSlot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSlot3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSlot4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSlot5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox PlayerSlot5;
        private System.Windows.Forms.PictureBox PlayerSlot4;
        private System.Windows.Forms.PictureBox PlayerSlot3;
        private System.Windows.Forms.PictureBox PlayerSlot2;
        private System.Windows.Forms.PictureBox PlayerSlot1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label pointTxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label countTxt;
        private System.Windows.Forms.Button bntPlay;
        private System.Windows.Forms.Label panelTxt;
    }
}